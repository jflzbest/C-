﻿namespace Article.PdfWeb.Models.Home {


    public class GenerateModel {

        // ------------------------------
        // Instance methods
        // ------------------------------

        public string Name { get; set; }
        public string Distance { get; set; }
        public string Date { get; set; }
        public string RaceName { get; set; }
        public bool ShowRulers { get; set; }

    }


}