﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KS3.Model
{
    public class ListBucketsRequest : KS3Request
    {
    }
}
